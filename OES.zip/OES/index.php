<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Input HTML Form Pack by Tooplate</title>
    <!--

    Template 2105 Input

	http://www.tooplate.com/view/2105-input

    -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/materialize.min.css">
    <link rel="stylesheet" href="css/tooplate.css">
    <link rel="icon" href="img/fav.png" type="image/png" sizes="16x16">

</head>

<body id="home">

<div class="col-xl-12 text-center font-weight-light">
           <div class="d-inline-block white-text py-2 tm-px-2">
               <img src="img/logo3.png" width="100%" height="200px">
           
       
           <h6 class="d-inline-block tm-bg-blac white-text py-2 tm-px-5" > 
            
            <a href="register.php" class="tm-white-text"> Register</a> &emsp; 
            <a href="login.php" class="tm-white-text"> Login</a>       &emsp;
            <a href="exam.php" class="tm-white-text"> Exam</a>     &emsp;
            <a href="ContactUs.php" class="tm-white-text"> ContactUs</a> </h6> 
        </div>
        </div>
         <div class="col-xl-12 text-center font-weight-light">
            <div class="d-inline-block tm-bg-black white-text py-2 tm-px-5">
                <h5>About</h6>
                <p>Dev Bhoomi Group Of Institutions(DBGI) established in the year 2009 is a premier group of institutions of Uttrakhand Uthan Samiti, a non-profit Society, professionally managed by the Eminent Academicians, Industrialists and Scientists. Keeping in tune with the upsurge in technical developments, the Samiti being committed to the cause of quality education and has established Six Temples of Learning and Innovations. DBGI is one of the best developing engineering colleges of Saharanpur district. The Campus is about 4 Km from Civil Hospital towards D.M. Residence at Beri Jama, Saharanpur. The nearest Airport is Jollygrant about 95 KMs from the Institute. The sprawling main campus is spread in one piece of land of 150 Bighas (22 acres), in the surroundings of greeneries, flora & fauna besides the National Forest.</p>
            </div>
            </div>
        </div>
    </div>
    <footer class="row tm-mt-big mb-3">
        <div class="col-xl-12 text-center font-weight-light">
            <p class="d-inline-block tm-bg-black white-text py-2 tm-px-5">
                Copyright &copy; 2020 Company Name - Design:
                <a rel="nofollow" href="https://www.dbgisre.edu.in/" class="tm-footer-link">Adit & Vashu</a>
            </p>
        </div>
    </footer>
</body>

</html>